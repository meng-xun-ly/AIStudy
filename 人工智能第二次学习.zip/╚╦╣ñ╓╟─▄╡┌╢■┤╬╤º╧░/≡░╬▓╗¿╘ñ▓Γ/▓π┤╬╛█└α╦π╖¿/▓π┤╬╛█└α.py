# 定义函数，将数据读取到列表中,每条数据以字典的形式保存
def read_data(filename, data_list):
    with open(filename, 'r') as file:
        lines = file.readlines()
        for line in lines:
            sp = line.split(',')
            info = {
                # 花萼长度
                'sepalLength': float(sp[0]),
                # 花萼宽度
                'sepalWidth': float(sp[1]),
                # 花瓣长度
                'petalLength': float(sp[2]),
                # 花瓣宽度
                'petalWidth': float(sp[3]),
                # 存放点的id
                'clusterID': int(-1)
            }
            data_list.append(info)
    return data_list


# 思想：就是每次选俩个数据计算距离，取最小的一个作为一组，在进行下一次运算



# 定义一个函数，计算俩个点之间的距离(以平方为例）
def countDistance(x,y):
    a = pow((data[x]['sepalLength'] - data[y]['sepalLength']), 2)
    b = pow((data[x]['sepalWidth'] - data[y]['sepalWidth']), 2)
    c = pow((data[x]['petalLength'] - data[y]['petalLength']), 2)
    d = pow((data[x]['petalWidth'] - data[y]['petalWidth']), 2)
    return a+b+c+d




# 定义一个函数将得到的最小一组转变为一个整体，并记录这个整体的中心点
def getmin(data,r):
    # 用来记录一组的
    count=[]
    again=[]   #重复元素存储
    s=0
    while len(data)>r:
        i=0
        mid_list=[]
        mid=float(999999)
        while i<len(data)-1:
            j=i+1
            while j<len(data):
                if countDistance(i,j)<mid:
                    mid=countDistance(i,j)
                    s1=data[i]
                    s2=data[j]
                j+=1
            i+=1
        mid_list.append(s1)
        mid_list.append(s2)

        # 这个地方的if-else语句一定要注意，不能并列写，否则就会出现精度损失
        if s1['clusterID']!=-1&s2['clusterID']==-1:
            count[s1['clusterID']].append(s2)
            flag=s1['clusterID']
        else :
            if s2['clusterID']!=-1&s1['clusterID']==-1:
                count[s2['clusterID']].append(s1)
                flag=s2['clusterID']
            else:
                if s1['clusterID']!=-1&s2['clusterID']!=-1:
                    flag=min(s1['clusterID'],s2['clusterID'])
                    count[flag]+=count[max(s1['clusterID'],s2['clusterID'])]
                    again.append(count[max(s1['clusterID'],s2['clusterID'])])
                else:
                    if s1['clusterID']==-1&s2['clusterID']==-1:
                        count.append(mid_list)
                        flag=s
                        s+=1
        info={
             # 花萼长度
            'sepalLength': float((s1['sepalLength']+s2['sepalLength'])/2),
            # 花萼宽度
            'sepalWidth': float((s1['sepalWidth']+s2['sepalWidth'])/2),
            # 花瓣长度
            'petalLength': float((s1['petalLength']+s2['petalLength'])/2),
            # 花瓣宽度
            'petalWidth': float((s1['petalWidth']+s2['petalWidth'])/2),
            # 存放点的id
            'clusterID': int(flag)
        }
        data.remove(s1)
        data.remove(s2)
        data.append(info)

    # 接下来是去重
    for y in again:
        count.remove(y)
    time=1
    for x in count:
        print('第%d组的个数为：%d'%(time,len(x)))
        time+=1
    print('\n')
    return count


# 画图
def show(picname,res):
    import matplotlib.pyplot as plt
    color=['blue','green','black','orange','purple','red','gold','gray']
    plt.title("SepalAfter")
    plt.xlabel("SepalLength")
    plt.ylabel("SepalWidth")
    sepalLengths=[]
    sepalWidths=[]
    for x in range(len(res)):
        sl=[]
        sw=[]
        for y in res[x]:
            sl.append(y['sepalLength'])
            sw.append(y['sepalWidth'])
        sepalLengths.append(sl)
        sepalWidths.append(sw)

    for i in range(len(res)):
        plt.plot(sepalLengths[i], sepalWidths[i], 'ro', color=color[i])
    plt.savefig(picname)


if __name__ == "__main__":
    data_list=[]
    data = read_data('../data.txt', data_list)
    print('请输入分类标准r:')
    r=input()
    res=getmin(data,int(r))
    picname='r_'+str(r)+'.png'
    show(picname,res)


#经过多次实验可以发现，最多分到五组！





