# 定义函数，将数据读取到列表中,每条数据以字典的形式保存
def read_data(filename, data_list):
    with open(filename, 'r') as file:
        lines = file.readlines()
        for line in lines:
            sp = line.split(',')
            info = {
                # 花萼长度
                'sepalLength': float(sp[0]),
                # 花萼宽度
                'sepalWidth': float(sp[1]),
                # 花瓣长度
                'petalLength': float(sp[2]),
                # 花瓣宽度
                'petalWidth': float(sp[3]),
                # 所属花的类别
                'kind': sp[4].strip('\n'),
                # 存放点的id
                'clusterID': int(-1)
            }
            data_list.append(info)
    return data_list

# 定义俩个值，一个是半径r,一个是阈值的个数value
# r=0.2
# value=10
# 说明：如果半径r内有value个值，就是核心点，如果没有，但是在核心点的阈值中，就是边界点；既不是核心点也不是边界点的是噪声点


# 定义一个函数，计算俩个点之间的距离(以平方为例）
def countDistance(x,y,data_list):
    a = pow((data_list[x]['sepalLength'] - data_list[y]['sepalLength']), 2)
    b = pow((data_list[x]['sepalWidth'] - data_list[y]['sepalWidth']), 2)
    c = pow((data_list[x]['petalLength'] - data_list[y]['petalLength']), 2)
    d = pow((data_list[x]['petalWidth'] - data_list[y]['petalWidth']), 2)
    return a+b+c+d

# 定义函数，判断是否是核心点
def isMeanPoint(x,data_list):
    count=[]
    num=0        #用来计数
    for i in range(len(data_list)):
        if countDistance(x,i,data_list)<r:
            num+=1
            count.append(i)
    if num>=value:
        return 1,count
    else:
        return 0,count


# 定义函数,返回所有的核心点
def getALLMainPoint(data_list):
    count=[]
    for i in range(len(data_list)):
        x,y=isMeanPoint(i,data_list)
        if x==1:
            count.append(i)
    return count



# 完成密度聚类算法
def dbscan(data_list):
    addsplit=[]
    count=getALLMainPoint(data_list)
    # 用来存放分类结果
    while len(count)>0:
        add=[]
        add.append(count[0])
        for i in count[1:-1]:
            if countDistance(count[0],i,data_list)<r:
                add.append(i)
        for i in add:
            count.remove(i)
        addsplit.append(add)
    i=0
    while i<len(addsplit)-1:
        j=i+1
        while j<len(addsplit):
            for a in addsplit[i]:
                for b in addsplit[j]:
                    if countDistance(a,b,data_list)<r:
                        break
            addsplit[i]+=addsplit[j]
            addsplit.remove(addsplit[j])
            j+=1
        i+=1
    for i in range(len(addsplit)):
        val=addsplit[i]
        for m in val:
            data_list[m]['clusterID']=i
            xi,yi=isMeanPoint(m,data_list)
            for s in yi:
                data_list[s]['clusterID']=i
    k=len(addsplit)
    return data_list,k


# 定义函数,显示分类结果
def countNum(data_list):
    x,y=dbscan(data_list)
    i=-1
    num=[]
    show_spw=[]
    show_spl=[]
    while i<y:
        count=0
        sw=list()
        sl=list()
        for s in x:
            if s['clusterID']==i:
                count+=1
                sl.append(s['sepalLength'])
                sw.append(s['sepalWidth'])
        i+=1
        num.append(count)
        show_spw.append(sw)
        show_spl.append(sl)
    print("\nr为%0.2f\tvalue为%d时候\n噪声点：%d个\t核心点有%d个\n分类结果分别为:"%(r,value,num[0],len(getALLMainPoint(data))),num)
    return num,show_spw,show_spl







# 画图显示结果
def show(picname):
    x,y,z=countNum(data_list)
    import matplotlib.pyplot as plt
    color=['blue','green','black','orange','purple','red','gold','gray']
    plt.title("SepalAfter")
    plt.xlabel("SepalLength")
    plt.ylabel("SepalWidth")
    for i in range(len(x)):
        plt.plot(z[i], y[i], 'ro', color=color[i])
    plt.savefig(picname)


if __name__ == "__main__":
    from decimal import Decimal
    data_list=[]
    data = read_data('../data.txt', data_list)
    print('请输入半径r:')
    r=input()
    r=float(r)
    print('请输入阈值value:')
    value=input()
    value=int(value)
    picname='r_'+str(Decimal(r).quantize(Decimal('0.0')))+'value_'+str(value)+'.png'
    show(picname)

