# 定义函数，将数据读取到列表中,每条数据以字典的形式保存
def read_data(filename, data_list):
    with open(filename, 'r') as file:
        lines = file.readlines()
        for line in lines:
            sp = line.split(',')
            info = {
                # 花萼长度
                'sepalLength': float(sp[0]),
                # 花萼宽度
                'sepalWidth': float(sp[1]),
                # 花瓣长度
                'petalLength': float(sp[2]),
                # 花瓣宽度
                'petalWidth': float(sp[3]),
                # 所属花的类别
                'kind': sp[4].strip('\n'),
                # 存放点的id
                'clusterID': int(-1)
            }
            data_list.append(info)
    return data_list


# 定义函数，将花萼花瓣在聚类前后的分布显示成图片
def show():
    # 聚类前
    kinds = ['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']
    sepalLegths = [[], [], []]
    sepalWidths = [[], [], []]
    petalLengths = [[], [], []]
    petalWidths = [[], [], []]
    for i in data:
        for x in range(3):
            if i['kind'] == kinds[x]:
                sepalLegth = i['sepalLength']
                sepalWidth = i['sepalWidth']
                petalLength = i['petalLength']
                petalWidth = i['petalWidth']
                sepalLegths[x].append(sepalLegth)
                sepalWidths[x].append(sepalWidth)
                petalLengths[x].append(petalLength)
                petalWidths[x].append(petalWidth)
    import matplotlib.pyplot as plt
    plt.title("SepalBefore")
    plt.xlabel("sepalLength")
    plt.ylabel("sepalWidth")
    color = ['blue', 'red', 'green']
    for i in range(3):
        plt.plot(sepalLegths[i], sepalWidths[i], 'ro', color=color[i])
    plt.show()
    plt.title("PetalBefore")
    plt.xlabel("petalLength")
    plt.ylabel("petalWidth")
    for i in range(3):
        plt.plot(petalLengths[i], petalWidths[i], 'ro', color=color[i])
    plt.show()
    # 聚类后
    cls = [int(0), int(1), int(2)]
    sepalLegths = [[], [], []]
    sepalWidths = [[], [], []]
    petalLengths = [[], [], []]
    petalWidths = [[], [], []]
    for i in data:
        for x in range(3):
            if i['clusterID'] == cls[x]:
                sepalLegth = i['sepalLength']
                sepalWidth = i['sepalWidth']
                petalLength = i['petalLength']
                petalWidth = i['petalWidth']
                sepalLegths[x].append(sepalLegth)
                sepalWidths[x].append(sepalWidth)
                petalLengths[x].append(petalLength)
                petalWidths[x].append(petalWidth)
    import matplotlib.pyplot as plt
    plt.title("SepalAfter")
    plt.xlabel("sepalLength")
    plt.ylabel("sepalWidth")
    color = ['red', 'green', 'blue']
    for i in range(3):
        plt.plot(sepalLegths[i], sepalWidths[i], 'ro', color=color[i])
    plt.show()
    plt.title("PetalAfter")
    plt.xlabel("petalLength")
    plt.ylabel("petalWidth")
    for i in range(3):
        plt.plot(petalLengths[i], petalWidths[i], 'ro', color=color[i])
    plt.show()


# 定义全局列表,用来存放质心
center_list = []
mean_split = []


# 定义的聚类函数
def Kmean():
    # 产生3个随机数，作为中心点
    import random
    a = random.sample(range(len(data) - 1), 3)
    for i in range(3):
        info = {
            # 'center_id':a[i],
            'sepalLength': data[a[i]]['sepalLength'],
            'sepalWidth': data[a[i]]['sepalWidth'],
            'petalLength': data[a[i]]['sepalLength'],
            'petalWidth': data[a[i]]['petalWidth'],
            'clusterID': i
        }
        data[a[i]]['clusterID'] = i
        center_list.append(info)


# 计算每个点距这3个点的距离，将最近的那个点作为中心点，并将标签该掉
def count_near():
    for i in data:
        dispow = []
        for x in center_list:
            a = pow((i['sepalLength'] - x['sepalLength']), 2)
            b = pow((i['sepalWidth'] - x['sepalWidth']), 2)
            c = pow((i['petalLength'] - x['petalLength']), 2)
            d = pow((i['petalWidth'] - x['petalWidth']), 2)
            dispow.append(a + b + c + d)
        i['clusterID'] = dispow.index(min(dispow))



# 重新计算质心
def count_near_while():
    mean_split = []
    for i in range(3):
        info = {
            'num': int(0),
            'sl': float(0),
            'sw': float(0),
            'pl': float(0),
            'pw': float(0),
            'id': i
        }
        mean_split.append(info)
    for i in data:
        for x in range(3):
            if i['clusterID'] == x:
                mean_split[x]['num'] = mean_split[x]['num'] + 1
                mean_split[x]['sl'] += i['sepalLength']
                mean_split[x]['sw'] += i['sepalWidth']
                mean_split[x]['pl'] += i['petalLength']
                mean_split[x]['pw'] += i['petalWidth']



# 如果质心不变了，就停止
    flag=0
    for y in range(3):
        if center_list[y]['sepalLength'] != mean_split[y]['sl'] / mean_split[y]['num'] or center_list[y]['sepalWidth'] != \
                mean_split[y]['sw'] / mean_split[y]['num'] or center_list[y]['petalLength'] != mean_split[y]['pl'] / \
                mean_split[y]['num'] or center_list[y]['petalWidth'] != mean_split[y]['pw'] / mean_split[y]['num']:
            center_list[y]['sepalLength'] = mean_split[y]['sl'] / mean_split[y]['num']
            center_list[y]['sepalWidth'] = mean_split[y]['sw'] / mean_split[y]['num']
            center_list[y]['petalLength'] = mean_split[y]['pl'] / mean_split[y]['num']
            center_list[y]['petalWidth'] = mean_split[y]['pw'] / mean_split[y]['num']
            flag=0
        else:
            flag=1
    if flag==0:
        count_near()
        print('id为0的个数是%d\tid为1的个数是%d\tid为2的个数是%d'%(mean_split[0]['num'],mean_split[1]['num'],mean_split[2]['num']))
    else:
        print('id为0的个数是%d\tid为1的个数是%d\tid为2的个数是%d,此条结果是最终结果'%(mean_split[0]['num'],mean_split[1]['num'],mean_split[2]['num']))
    return flag



if __name__ == "__main__":
    data_list = []
    data = read_data('../data.txt', data_list)
    Kmean()
    count_near()
    for i in range(1,100):
        print('第',i,'次聚类后结果为：')
        if count_near_while()==1:
            break
    show()
