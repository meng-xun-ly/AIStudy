import random


# 读取数据集中的数据
def read_data(filename, data_list):
    with open(filename, 'r') as file:
        lines = file.readlines()
        for line in lines:
            info = []
            sp = line.strip('\n').split(',')
            for i in sp:
                if i == 'R' or i == 'M':
                    info.append(str(i))
                else:
                    info.append(float(i))
            data_list.append(info)
    return data_list


# 定义函数，用来构建新的测试样本
def getnewdata(data_list):
    new_data = []
    i = 0
    while i < len(data_list):
        new_data.append(data_list[random.randint(0, len(data_list) - 1)])
        i += 1
    return new_data


# 定义函数，用来随机得到m个特征来做基分类器的训练标准
def getMfeatures(m):
    m_count = (random.sample(range(0, 59), m))
    return m_count


# 按照基尼系数来确定这m个特征的分类顺序
def countGini(data_list):
    if len(data_list) == 0:
        return 0
    else:
        countR = 0
        for i in data_list:
            if i[-1] == 'R':
                countR += 1
        p = countR / len(data_list)
        return 2 * p - 2 * pow(p, 2)


# 定义左右子集，用来存放分类后的结果，按照gini系数的大小来选择最佳的分类值（不是分类特征）
def getBestValue(data_list, features):
    mid = []
    for x in features:
        for y in data_list:
            left = []
            right = []
            for z in data_list:
                if z[x] < y[x]:
                    left.append(z)
                else:
                    right.append(z)

            gini = (countGini(left) * len(left) + countGini(right) * len(right)) / len(data_list)
            info = {
                'gini': gini,
                'value': y[x],
                'feature': x
            }
            mid.append(info)
    best_gini = 9999
    for s in mid:
        if s['gini'] < best_gini:
            # best_gini=s['gini']
            best_value = s['value']
            best_feature = s['feature']
    return best_feature, best_value  # 获取到以value列来划分时候的最佳分类值max


# # 定义一个函数，用来判断是否标签全部一致，如果是，这个分支就直接停止分类,函数返回标签值R，M，否则返回F
def isOver(data_list):
    countR = 0
    for i in data_list:
        if i[-1] == 'R':
            countR += 1
    if countR == len(data_list):
        return 'R'
    else:
        if countR == 0:
            return 'M'
        else:
            return 'F'


# 构建决策树，用来作为基学习器,注意：0.3个部分为测试集，0.7个部分为训练集
def bulidtree(data_list,features_line,bestvalues_line):
    split = []
    j = 0  # 树的层数
    left = []
    right = []
    for i in data_list:
        if i[features_line[j]] <= bestvalues_line[j]:
            left.append(i)
        else:
            right.append(i)
    info_left = {
        'str': str(0),
        'data': left,
        'flag': isOver(left),
        'id': int(j)
    }
    info_right = {
        'str': str(1),
        'data': right,
        'flag': isOver(right),
        'id': int(j)
    }
    if len(left)!=0:
        split.append(info_left)
    if len(right)!=0:
        split.append(info_right)
    j = 1
    while j < len(features_line):
        for s in split:
            left = []
            right = []
            if s['id'] == j - 1 and s['flag'] == 'F':
                for i in s['data']:
                    if i[j] < bestvalues_line[j]:
                        left.append(i)
                    else:
                        right.append(i)
                s['data'] = []
                info_left = {
                    'str': s['str'] + str(0),
                    'data': left,
                    'flag': isOver(left),
                    'id': int(j)
                }
                info_right = {
                    'str': s['str'] + str(1),
                    'data': right,
                    'flag': isOver(right),
                    'id': int(j)
                }
                if len(left)!=0:
                    split.append(info_left)
                if len(right)!=0:
                    split.append(info_right)
        j += 1

    # 最后，用F(不确定的标签)中占比较多的标签作为输出标签
    id_list = []
    for i in split:
        id_list.append(i['id'])
    for i in split:
        if i['id'] == max(id_list) and i['flag'] == 'F':
            countR = 0
            for s in i['data']:
                if s[-1] == 'R':
                    countR += 1
            if 2 * countR > len(i['data']):
                i['flag'] = 'R'
            else:
                i['flag'] = 'M'
    res=[]
    for i in split:
        if i['flag']!='F':
            res.append(i)
    return res


# 划分数据集和测试集,3/7分，注意一定要随机3-7，不然可能就会出现跑分为0的情况，因为标签聚集了
def splitdata(data_list):
    train_data=[]
    test_data=[]
    num=(random.sample(range(0, len(data_list)-1), int(7 * len(data_list) / 10)))
    for i in num:
        train_data.append(data_list[i])
    for s in range(0,len(data_list)-1):
        if s not in num:
            test_data.append(data_list[s])
    return train_data, test_data


# 这个函数在getscore中会用到
def returnkey(data_list, test_str):
    for i in data_list:
        if isSame(test_str,i['str'])==True:
            return i


def isSame(test_str,train_str):
    if len(test_str)>=len(train_str):
        for i in range(len(train_str)):
            if test_str[i]!=train_str[i]:
                return False
    else:
        return False
    return True



# 定义一个函数，用来计算测试集跑训练模型的得分
def getscore(train_data, test_data,features_line,bestvalues_line):
    # 按照模型跑一遍，目的只是为了得到分类后的str转码，因为模型的准确值使用train跑出来的，这里得到转码就去和model里面的值进行对比
    train = bulidtree(train_data,features_line,bestvalues_line)
    test = bulidtree(test_data,features_line,bestvalues_line)
    # print(train,test)
    count = 0
    for x in test:
        for y in x['data']:
            if returnkey(train, x['str']):
                if x['str'] == returnkey(train, x['str'])['str'] and y[-1] == returnkey(train, x['str'])['flag']:
                    count += 1
    return count / len(test_data)

# 定义一个函数，在决策分类树的基础上构建随机森林
def randomForest(tree_num,feature_num,data_list):   #分别表示为随机森林中决策树的数目，决策树分类的特征数，用来分类的总的训练集
    scores=[]
    # 按照三七分得到训练集和测试集
    data, test = splitdata(data_list)
    for time in range(tree_num):
        train_data = getnewdata(data)
        # 随机获取m个特征
        features = getMfeatures(feature_num)
        # 最优特征排序
        features_line = []
        bestvalues_line = []
        for i in range(len(features)):
            x, y = getBestValue(train_data, features)
            features_line.append(x)
            bestvalues_line.append(y)
            features.remove(x)
        score=getscore(train_data,test,features_line,bestvalues_line)
        scores.append(score)
        print('第%d个基学习器跑出的得分为：%f'%(time+1,score))
    countscores=0.0
    for i in scores:
        countscores+=i
    print('\n利用随机森林整体得分为：%f'%(countscores/len(scores)))
    # return countscores/len(scores)




if __name__ == '__main__':
    data_list = []
    data_list = read_data('sonar-all-data.txt', data_list)
    import matplotlib.pyplot as plt
    plt.title('PredictSuccess--TreeNum')
    plt.xlabel('TreeNum')
    plt.ylabel('PrerdictSuccess')
    scores=[]
    # for s in range(1,101,1):
    #     scores.append(randomForest(s,5,data_list))
    # plt.plot(range(1,101),scores,'k-',color='red')
    # plt.savefig('PredictSuccess_TreeNum.png')
    # plt.show()
    randomForest(1,5,data_list)
