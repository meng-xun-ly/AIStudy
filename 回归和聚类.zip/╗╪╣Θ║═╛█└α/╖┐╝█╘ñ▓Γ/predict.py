# 定义函数，将数据读取到列表中,每条数据以字典的形式保存
def read_data(filename, data_list):
    with open(filename, 'r') as file:
        lines = file.readlines()
        for line in lines:
            sp = line.split(',')
            info = {
                'area': int(sp[0]),
                'price': int(sp[1].strip('\n'))
            }
            data_list.append(info)
    return data_list




# 定义函数，实现线性回归算法
def lineReg(data):
    sumXY = sumX = sumY = sumXX = 0
    dataNum = len(data)
    for i in data:
        sumXY = sumXY + i['area'] * i['price']
        sumX = sumX + i['area']
        sumY = sumY + i['price']
        sumXX = sumXX + i['area'] * i['area']
    b = (sumXY * dataNum - sumX * sumY) / (sumXX * dataNum - sumX * sumX)
    a = sumY / dataNum - b * sumX / dataNum
    print('线性回归函数为：Y =','%.2f'%b,'X +','%.2f'%a+'\n')
    return a,b

# 画出散点图和回归曲线
def showpicture(a,b):
    areas=[]
    prices=[]
    for i in data:
        area=int(i['area'])
        price=int(i['price'])/10000
        areas.append(area)
        prices.append(price)
    import numpy as np
    import matplotlib.pyplot as plt
    plt.title("HousePricePredict")
    plt.xlim(xmax=500,xmin=50)
    plt.ylim(ymax=750,ymin=150)
    plt.xlabel("Area/m^2")
    plt.ylabel("Price/w")
    x=np.linspace(50,500)
    y=b*x+a
    y=y/10000
    plt.plot(x,y,'k-',color="blue")
    plt.plot(areas,prices,'ro')
    plt.show()


if __name__=="__main__":
    data_list = []
    data = read_data('data.txt', data_list)
    area=0
    a,b=lineReg(data)
    print('请输入房子的面积(单位：平方米):')
    area=input()
    area=int(area)
    print('由面积初步估计该房子的价格为:','%.2f' %(b*area+a)+'元')
    showpicture(a,b)

